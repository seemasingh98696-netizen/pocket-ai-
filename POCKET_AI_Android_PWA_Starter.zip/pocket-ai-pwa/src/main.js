import "./style.css";
import { LocalEngine } from "./engine.js";
import { addMessage, getMessages, clearMessages, saveModel, getModel } from "./db.js";

const $ = id => document.getElementById(id);
const network = $("network"), modelName = $("modelName"), engineStatus = $("engineStatus");
const modelFile = $("modelFile"), loadButton = $("loadModel"), modelProgress = $("modelProgress");
const progressBar = $("progressBar"), modelNote = $("modelNote"), messagesEl = $("messages");
const promptEl = $("prompt"), sendButton = $("send");
let selectedFile = null, engine = new LocalEngine(), history = [], busy = false;

function setNetwork() {
  const online = navigator.onLine;
  network.textContent = online ? "ONLINE" : "OFFLINE";
  network.classList.toggle("offline", !online);
}
window.addEventListener("online", setNetwork);
window.addEventListener("offline", setNetwork);
setNetwork();

function addBubble(role, content, error = false) {
  const welcome = messagesEl.querySelector(".welcome");
  if (welcome) welcome.remove();
  const node = document.createElement("div");
  node.className = `message ${role}${error ? " error" : ""}`;
  node.textContent = content;
  messagesEl.append(node);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}
function renderHistory() {
  messagesEl.innerHTML = "";
  if (!history.length) {
    messagesEl.innerHTML = '<div class="welcome"><div class="welcome-icon">✦</div><h3>Your AI stays on your device.</h3><p>Load a compatible model to begin. No cloud answers or simulated replies.</p></div>';
  } else history.forEach(m => addBubble(m.role, m.content));
}
async function persist(role, content) {
  const item = {role, content, createdAt: Date.now()};
  history.push(item);
  await addMessage(item);
  addBubble(role, content);
}
function setReady(ready) {
  promptEl.disabled = !ready;
  sendButton.disabled = !ready;
  engineStatus.textContent = ready ? "LOCAL ENGINE READY" : "ENGINE NOT READY";
  engineStatus.style.color = ready ? "#8fe0b1" : "";
}

modelFile.addEventListener("change", () => {
  selectedFile = modelFile.files?.[0] || null;
  loadButton.disabled = !selectedFile || !selectedFile.name.toLowerCase().endsWith(".gguf");
  if (selectedFile) {
    modelName.textContent = selectedFile.name;
    modelNote.textContent = `${(selectedFile.size / 1024 ** 3).toFixed(2)} GB selected. It will be copied into browser storage.`;
  }
});

loadButton.addEventListener("click", async () => {
  if (!selectedFile || busy) return;
  busy = true; loadButton.disabled = true;
  modelProgress.hidden = false; progressBar.style.width = "0%";
  modelNote.textContent = "Saving model locally. Keep this tab open.";
  try {
    await saveModel(selectedFile, selectedFile.name);
    modelName.textContent = selectedFile.name;
    modelNote.textContent = "Model saved locally. Starting local inference runtime…";
    await engine.load(selectedFile, p => {
      const value = typeof p === "number" ? p : (p?.loaded && p?.total ? p.loaded / p.total * 100 : 0);
      progressBar.style.width = `${Math.max(0, Math.min(100, value))}%`;
    });
    setReady(true);
    modelNote.textContent = "Model loaded. You can now disconnect the internet and chat.";
  } catch (err) {
    setReady(false);
    modelNote.textContent = `Could not load model: ${err?.message || err}. Check runtime files, model compatibility and available RAM.`;
    addBubble("assistant", "The local model could not be started. No AI response was generated.", true);
  } finally {
    busy = false; loadButton.disabled = !selectedFile;
  }
});

async function send() {
  const prompt = promptEl.value.trim();
  if (!prompt || busy || !engine.instance) return;
  promptEl.value = ""; busy = true; sendButton.disabled = true;
  try {
    await persist("user", prompt);
    const answer = await engine.reply(history.slice(0, -1), prompt);
    if (!answer || !String(answer).trim()) throw new Error("The model returned an empty response.");
    await persist("assistant", String(answer).trim());
  } catch (err) {
    addBubble("assistant", `Local inference error: ${err?.message || err}`, true);
  } finally {
    busy = false; sendButton.disabled = false; promptEl.focus();
  }
}
sendButton.addEventListener("click", send);
promptEl.addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } });
$("clearChat").addEventListener("click", async () => {
  if (!confirm("Clear this conversation history? Your downloaded model will NOT be deleted.")) return;
  await clearMessages(); history = []; renderHistory();
});

async function init() {
  if ("serviceWorker" in navigator) {
    try { await navigator.serviceWorker.register("/sw.js"); } catch (e) { console.warn("Service worker registration failed", e); }
  }
  history = await getMessages();
  renderHistory();
  const stored = await getModel();
  if (stored?.name) {
    modelName.textContent = stored.name;
    modelNote.textContent = "A model file is saved on this device. Select it again to load it into the local engine.";
  }
  // Model bytes are intentionally retained. User explicitly chooses when to load.
}
init().catch(err => console.error(err));
