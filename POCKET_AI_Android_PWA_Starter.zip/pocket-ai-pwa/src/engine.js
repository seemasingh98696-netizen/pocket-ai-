/*
 * Local GGUF inference adapter.
 *
 * This project uses wllama (llama.cpp compiled for WebAssembly).
 * The runtime package must be installed at build time and its matching
 * WASM assets must be copied into /wllama/ by the setup instructions.
 *
 * API details can change between wllama releases. Keep this adapter isolated
 * so the runtime can be updated without changing the UI or local database.
 */
import { Wllama } from "@wllama/wllama";

export class LocalEngine {
  constructor() { this.instance = null; }
  async load(blob, onProgress = () => {}) {
    const wasmPaths = {
      "single-thread/wllama.js": "/wllama/single-thread/wllama.js",
      "single-thread/wllama.wasm": "/wllama/single-thread/wllama.wasm",
      "multi-thread/wllama.js": "/wllama/multi-thread/wllama.js",
      "multi-thread/wllama.wasm": "/wllama/multi-thread/wllama.wasm"
    };
    this.instance = new Wllama(wasmPaths);
    const localUrl = URL.createObjectURL(blob);
    try {
      await this.instance.loadModelFromUrl(localUrl, {
        n_ctx: 2048,
        progress_callback: progress => onProgress(progress)
      });
    } finally {
      URL.revokeObjectURL(localUrl);
    }
  }
  async reply(history, prompt) {
    if (!this.instance) throw new Error("No local model is loaded.");
    const transcript = history.map(m => `${m.role === "user" ? "User" : "Assistant"}: ${m.content}`).join("\\n");
    const fullPrompt = `${transcript}\\nUser: ${prompt}\\nAssistant:`;
    return await this.instance.createCompletion(fullPrompt, {
      nPredict: 256,
      sampling: { temp: 0.7, top_p: 0.9 }
    });
  }
  async unload() {
    if (this.instance?.exit) await this.instance.exit();
    this.instance = null;
  }
}
