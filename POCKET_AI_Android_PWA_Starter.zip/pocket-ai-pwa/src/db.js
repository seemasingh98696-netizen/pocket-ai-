const DB_NAME = "pocket-ai-local";
const DB_VERSION = 1;
function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains("settings")) db.createObjectStore("settings");
      if (!db.objectStoreNames.contains("messages")) db.createObjectStore("messages", { keyPath: "id", autoIncrement: true });
      if (!db.objectStoreNames.contains("models")) db.createObjectStore("models");
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}
async function request(store, mode, action) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, mode);
    const req = action(tx.objectStore(store));
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
    tx.oncomplete = () => db.close();
  });
}
export const saveSetting = (key, value) => request("settings", "readwrite", s => s.put(value, key));
export const getSetting = key => request("settings", "readonly", s => s.get(key));
export const addMessage = message => request("messages", "readwrite", s => s.add(message));
export const getMessages = () => request("messages", "readonly", s => s.getAll());
export const clearMessages = () => request("messages", "readwrite", s => s.clear());
export const saveModel = (blob, name) => request("models", "readwrite", s => s.put({blob, name, savedAt: Date.now()}, "active"));
export const getModel = () => request("models", "readonly", s => s.get("active"));
// Deliberately no automatic model deletion function.
