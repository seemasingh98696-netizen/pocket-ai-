# POCKET AI — Android offline-first PWA

This is a starter PWA shell for local GGUF inference. It does **not** call Gemini, OpenAI, or a cloud chat endpoint.

## Important runtime setup

The app uses `@wllama/wllama` (llama.cpp compiled to WebAssembly) as its local inference runtime. The package's matching WASM assets must be served locally by the PWA. Do not use a CDN for these files if you want inference to work offline.

1. Install Node.js on a computer or a supported cloud build environment:
   ```bash
   npm install
   ```
2. Inspect the installed `@wllama/wllama` package's `dist` directory and copy its matching single-thread and multi-thread runtime files into:
   - `public/wllama/single-thread/`
   - `public/wllama/multi-thread/`

   Keep the exact filenames expected by your installed wllama release. The adapter currently expects `wllama.js` and `wllama.wasm` in each folder. If the package release uses different filenames or constructor/load options, update `src/engine.js` to match that release's documented API.
3. Build and host the `dist/` folder over HTTPS:
   ```bash
   npm run build
   ```
4. Open the HTTPS URL in Android Chrome, use **Install app** / **Add to Home screen**, then open POCKET AI.
5. Choose a compatible `.gguf` model file from device storage and load it. Wait until the engine reports ready. Then test with airplane mode enabled.

## Android notes

- Browser PWA storage and memory limits vary by Android version and device. A 1B model may be too large or slow on some phones. Start with a small, quantized GGUF and modest context length.
- Model import copies the selected file into IndexedDB. Large files may exceed quota or cause memory pressure. The browser can evict site data under storage pressure; no web app can guarantee permanent retention. Back up important model files elsewhere.
- The first website visit and app-shell installation require internet. Model download/import also requires access to the model file. Once the app shell, WASM runtime, and model are stored, inference is local.
- Service workers require HTTPS (except localhost).
- This project deliberately does not invent responses: without a loaded model, chat is disabled.
- GGUF support is not universal. The model architecture and quantization must be supported by the exact llama.cpp/WASM build.

## Security and privacy

Chat history and the imported model are stored in this browser's IndexedDB origin. Clearing site data from Android/browser settings can remove them. Do not clear site data if you want to retain local content.

## Current scope

Included: PWA manifest, service worker shell caching, offline/online indicator, IndexedDB chat history and model persistence, GGUF file selection, local runtime adapter, chat UI.

Still required before production: verify the exact wllama release API and copy its matching WASM binaries locally; test on the target Android device with the chosen GGUF model. This source project is not a claim that every GGUF model will run on every phone.
